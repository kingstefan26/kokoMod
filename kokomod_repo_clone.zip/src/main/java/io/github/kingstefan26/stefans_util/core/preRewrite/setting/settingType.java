package io.github.kingstefan26.stefans_util.core.preRewrite.setting;

public enum settingType {
    COMBO, CHECK, SLIDER
}
