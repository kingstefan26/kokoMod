package io.github.kingstefan26.stefans_util.core.onlineFeatures.repo.objects;

import com.google.gson.JsonElement;

public class mainRepoObject {
    public JsonElement webModulesURL;
}
