package io.github.kingstefan26.stefans_util.core.onlineFeatures.repo.objects;

public class webModuleObject {
    public String type;
    public String classpath;
    public String classLocation;
    public String[] dependencies;
}
