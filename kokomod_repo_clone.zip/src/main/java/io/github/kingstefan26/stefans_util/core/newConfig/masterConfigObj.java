package io.github.kingstefan26.stefans_util.core.newConfig;

import io.github.kingstefan26.stefans_util.core.globals;

public class masterConfigObj {
    String version = globals.VERSION;
    configObj[] configObjs;
}
