package io.github.kingstefan26.stefans_util.util.renderUtil;

import org.lwjgl.opengl.Display;

public class updateWidowTitle {
    public static void updateTitle(String windowTitle) {
        Display.setTitle(windowTitle);
    }
}
