package io.github.kingstefan26.stefans_util.module.macro.util;

public enum macroStages {
    LEFT,RIGHT,TOP,BOTTOM,HOLD,DEFAULT
}
