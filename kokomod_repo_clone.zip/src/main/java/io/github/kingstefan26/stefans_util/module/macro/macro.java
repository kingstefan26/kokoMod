package io.github.kingstefan26.stefans_util.module.macro;

public interface macro {
}
