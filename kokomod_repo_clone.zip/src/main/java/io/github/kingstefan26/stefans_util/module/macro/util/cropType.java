package io.github.kingstefan26.stefans_util.module.macro.util;

public enum cropType {
	WART, CANE, WHEAT, PUMPKIN, MELON, CARROT, POTATO, DEFAULT
}
