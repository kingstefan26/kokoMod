package io.github.kingstefan26.stefans_util.service;

public enum ServiceStatusEnum {
    NULL, STOPPING, STOPPED, INITIALISING, RUNNING, ERRORED
}
