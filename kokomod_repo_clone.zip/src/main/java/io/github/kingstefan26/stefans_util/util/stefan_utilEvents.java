package io.github.kingstefan26.stefans_util.util;

import net.minecraftforge.fml.common.eventhandler.Event;

public class stefan_utilEvents {
    public static class joinedDungeonEvent extends Event {
    }
    public static class joinedPrivateIslandEvent extends Event {
    }
    public static class joinedSkyblockEvent extends Event {
    }
    public static class leftDungeonEvent extends Event{
    }
    public static class leftPrivateIslandEvent extends Event {
    }
    public static class leftSkyblockEvent extends Event{
    }
    public static class playerFallEvent extends Event {
    }
    public static class playerTeleportEvent extends Event {
    }
    public static class receivedKeepAlivePacketEvent extends Event {
    }
    public static class clickedUnlockKeyEvent extends Event {}


}
