package io.github.kingstefan26.stefans_util.core.config;

public enum confgValueType {
    BOOLEAN, DOUBLE, INT, STRING, PERSISTENT
}
